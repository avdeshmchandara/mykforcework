import json
import urllib.parse
import boto3
import os
import logging
import time
import json
import pandas as pd
import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

region_name= os.environ['REGION_NAME']
acc_num = os.environ['ACCOUNT_NUMBER']
env_run = os.environ['ENV']

s3c = boto3.client('s3')
s3r = boto3.resource('s3')
stepc = boto3.client('stepfunctions')
step_fnc_name = "ocse-deid-main-raw-workflow"
landbucket = "ocse-{env_run}-deid-main-raw-data".format(env_run=env_run)
rawbucket  = "ocse-{env_run}-deid-main-raw-data".format(env_run=env_run)

def get_file_list(landbucket, landfolder):
    files = []
    try:
        rsp = s3c.list_objects_v2(Bucket=landbucket, Prefix=landfolder)
        for obj in rsp['Contents']:
            if obj['Size'] > 0:
                files.append(obj['Key'])
        return files
    except Exception as e:
        print("Unable to obtain file list:: ", e)
        return files

def filter_list_substring(substr, mylist):
    sublist = []
    for mm in mylist:
        if substr in mm:
            sublist.append(mm)
    return sublist


def flat_list_list(unflat):
    flatlist = []
    for sub_list in unflat:
        for name in sub_list:
            flatlist.append(name)
    return flatlist

def get_lists_datasets(schtablist):
    if len(schtablist)==0:
        return ([], [], [])
    df = pd.DataFrame({'landfiles': schtablist})
    df['csvfile'] = df['landfiles'].apply(lambda x: os.path.basename(x))
    df['tablename'] = df['landfiles'].apply(lambda x: x.split('/')[-3]+"_"+x.split('/')[-2])
    gdf1 = df.groupby('tablename')['csvfile'].apply(list).reset_index(name='listcsv')
    gdf2 = df.groupby('tablename')['landfiles'].apply(list).reset_index(name='listland')
    datasets = gdf1['tablename'].tolist()
    listcsvs = gdf1['listcsv'].tolist()
    listlands = gdf2['listland'].tolist()
    return (datasets, listcsvs, listlands)


def movefiles_submitjob(schtablist, landfolder, targetfolder):
    datasets, listcsvs, listlands = get_lists_datasets(schtablist)
    for ii in range(len(datasets)):
        dataset = datasets[ii]
        listcsv = listcsvs[ii]
        listland = listlands[ii]

        for schema_a in range(len(listland)):
            landfile = listland[schema_a]
            csvfile  = listcsv[schema_a]
            landcopy = {'Bucket': landbucket, 'Key': landfile}
            rawkey = landfile.replace(landfolder, targetfolder)
            cops = s3r.meta.client.copy(landcopy, rawbucket, rawkey)
            dops = s3r.Object(landbucket, landfile).delete()

        topicname = "ocse-deid-main-job-events"
        queuename = "ocse-da-main-trigger-curate-queue"
        input_msg = {
                        "Dataset": dataset,
                        "EnvName": env_run,
                        "AccountId": acc_num,
                        "TopicName": topicname,
                        "QueueName": queuename
                   }        
        input_to_sm = json.dumps(input_msg, indent = 4)
        sfname = dataset + "_" + str(datetime.datetime.today().strftime('%Y%m%d_%H%M%S'))
        arn_step =  "arn:aws:states:{}:{}:stateMachine:".format(region_name, acc_num) 
        rsp = stepc.start_execution(stateMachineArn=arn_step+step_fnc_name, input=input_to_sm, name=sfname)


def lambda_handler(event, context):
    try:
        print("event is",event, event.keys() )
        
        allfilesmoved = []
        tablenames = {}
        landfolder = event['source-fldr-nm']
        targetfolder = event['target-fldr-nam']
        
        for db_sch, tabdict in event.items():
            if isinstance(tabdict, dict):
                tablenames[event[db_sch]['schema-fldr-nm']] = event[db_sch]['table-names']

        for schema_a, tablist_a in tablenames.items():
            schema = schema_a
            tables = tablenames[schema_a]

            files = get_file_list(landbucket, landfolder+"/"+schema_a)
            schtablist = []
            for tab in tables:
                if tab.upper()=="ALL":
                    schtablist = [files]
                else:
                    schtablist.append( filter_list_substring( str(schema+"/"+tab+"/"), files )  )
                    
            schtablist = flat_list_list(schtablist)
            #print("schtablist::  ", schtablist)
            movefiles_submitjob(schtablist, landfolder, targetfolder)
            allfilesmoved.append(schtablist)

    except Exception as e:
        print(e)
        logger.error(e)
        raise e 
    
    return {
        'Status': 200,
        'body': json.dumps("List of moved files::  "+str(flat_list_list(allfilesmoved)))
    }
